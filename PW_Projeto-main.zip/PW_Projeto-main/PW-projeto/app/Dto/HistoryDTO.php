<?php

namespace App\Dto;

class HistoryDTO
{

}
